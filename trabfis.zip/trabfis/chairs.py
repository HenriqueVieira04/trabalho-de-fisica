import pygame
import sys
import math

# Inicializa o Pygame
pygame.init()

# Definir dimensões da tela
largura = 1600
altura = 1200
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption('Chairs!')

# Cores
BRANCO = (255, 255, 255)
AZUL = (0, 0, 255)
AZUL_ESCURO = (23, 20, 31)
VERMELHO = (255, 0, 0)
PRETO = (0, 0, 0)
VERDE = (0, 255, 0)
ROXO = (166, 38, 166)

# Fontes
fonte1 = pygame.font.SysFont(None, 60)  
fonte2 = pygame.font.SysFont("Cantarell", 72, bold=True)
fonte3 = pygame.font.SysFont("Cantarell", 36, bold=True)
fonte4 = pygame.font.SysFont(None, 62)
fonte5 = pygame.font.SysFont(None, 20)

#seleções
dificuldade = 1
fases = 1

#---------------------------------------------------------------------------
def atualizar_posicao_e_velocidade(t, angulo, velocidade_inicial, posicao_inicial_x, posicao_inicial_y, g):
    angulo_rad = math.radians(angulo)
    velocidade_inicial_x = velocidade_inicial * math.cos(angulo_rad)
    velocidade_inicial_y = velocidade_inicial * math.sin(angulo_rad)
    x = posicao_inicial_x + velocidade_inicial_x * t
    y = posicao_inicial_y - (velocidade_inicial_y * t - 0.5 * g * t**2)
    return (x, y), (velocidade_inicial_x, velocidade_inicial_y - g * t)

def desenhar_vetor_direcao(x, y, angulo, velocidade_inicial):
    comprimento_vetor = velocidade_inicial * 0.5
    angulo_rad = math.radians(angulo)
    fim_vetor_x = x + comprimento_vetor * math.cos(angulo_rad)
    fim_vetor_y = y - comprimento_vetor * math.sin(angulo_rad)
    pygame.draw.line(tela, ROXO, (int(x), int(y)), (int(fim_vetor_x), int(fim_vetor_y)), 3)

    comprimento_seta = 12
    angulo_seta = math.radians(25)
    ponta1_x = fim_vetor_x - comprimento_seta * math.cos(angulo_rad - angulo_seta)
    ponta1_y = fim_vetor_y + comprimento_seta * math.sin(angulo_rad - angulo_seta)
    ponta2_x = fim_vetor_x - comprimento_seta * math.cos(angulo_rad + angulo_seta)
    ponta2_y = fim_vetor_y + comprimento_seta * math.sin(angulo_rad + angulo_seta)
    pygame.draw.polygon(tela, ROXO, [(fim_vetor_x, fim_vetor_y), (ponta1_x, ponta1_y), (ponta2_x, ponta2_y)])

def verificar_colisao(x1, y1, x2, y2, raio_objeto1, raio_objeto2):
    distancia = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    return distancia <= (raio_objeto1 + raio_objeto2)

def reposicionar_marcal():
    # Gera uma nova posição aleatória para o marcal
    import random
    novo_x = random.randint(700, largura - 300)
    novo_y = random.randint(250, altura - 300)
    return novo_x, novo_y

def processar_entrada_continua(sens_ang, sens_vel, lancado, angulo, velocidade_inicial):
    
    # Obtém o estado atual de todas as teclas
    teclas = pygame.key.get_pressed()

    #restart do jogo
    restart = True

    # Ajusta o ângulo
    if teclas[pygame.K_UP]:
        angulo += sens_ang
    if teclas[pygame.K_DOWN]:
        angulo -= sens_ang
        
    # Ajusta a velocidade
    if teclas[pygame.K_RIGHT]:
        velocidade_inicial += sens_vel
    if teclas[pygame.K_LEFT]:
        velocidade_inicial -= sens_vel

    if teclas[pygame.K_RETURN]:
        lancado = True;
    if teclas[pygame.K_SPACE]:
        restart = False
    
    # Limita o ângulo entre 0 e 90 graus
    angulo = max(0, min(90, angulo))
    # Limita a velocidade inicial entre 0 e 100
    velocidade_inicial = max(0, min(150, velocidade_inicial))

    return angulo, velocidade_inicial, lancado, restart

def mostrar_resultados(pontuacao, meta):
    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_SPACE:  # Reinicia o jogo
                    return

        # Mostrar textos
        texto_fim = fonte1.render("FIM DE JOGO!", True, BRANCO)
        texto_pontuacao_final = fonte1.render(f"Pontuação Final: {pontuacao}", True, BRANCO)
        texto_reiniciar = fonte1.render("Pressione ESPAÇO para jogar novamente", True, BRANCO)
        
        if(pontuacao >= meta):
            texto_desfecho = fonte1.render("PARABENS! você venceu esta fase", True, VERDE)
        else:
            texto_desfecho = fonte1.render("Não foi dessa vez, tente novamente...", True, VERMELHO)

        tela.blit(texto_fim, (largura // 2 - texto_fim.get_width() // 2, altura // 2 - 100))
        tela.blit(texto_desfecho, (largura // 2 - texto_desfecho.get_width() // 2, altura // 2 - 200))
        tela.blit(texto_pontuacao_final, (largura // 2 - texto_pontuacao_final.get_width() // 2, altura // 2 - 300))
        tela.blit(texto_reiniciar, (largura // 2 - texto_reiniciar.get_width() // 2, altura // 2 - 400))

        pygame.display.flip()
#---------------------------------------------------------------------------

# Função para desenhar o menu
def draw_menu():
    planofundo = pygame.image.load("images/startmenu.webp")
    planofundo = pygame.transform.scale(planofundo, (1600, 1200))
    
    tela.blit(planofundo, (0, 0))

    # Desenhando o título
    titulo = fonte2.render('Chairs: throw at Marçal', True, BRANCO)
    tela.blit(titulo, (largura // 2 - titulo.get_width() // 2, 100))

    # Botão "Iniciar Jogo"
    start_button = pygame.Rect(150, 250, 300, 50)
    pygame.draw.rect(tela, BRANCO, start_button, border_radius=20)
    start_text = fonte3.render('Iniciar Jogo', True, PRETO)
    
    tela.blit(start_text, (start_button.left + start_button.width//2 - start_text.get_width()//2,
    start_button.top+start_button.height//2 - start_text.get_height()//2))

    #Botão "Dificuldade"
    dificult_button = pygame.Rect(150, 350, 300, 50)
    pygame.draw.rect(tela, BRANCO, dificult_button, border_radius=20)
    dificult_text = fonte3.render('Dificuldade', True, PRETO)

    tela.blit(dificult_text,(dificult_button.left + dificult_button.width//2 - dificult_text.get_width()//2,
    dificult_button.top+dificult_button.height//2 - dificult_text.get_height()/2))

    #Botão "Fases"
    fases_button = pygame.Rect(150, 450, 300, 50)
    pygame.draw.rect(tela, BRANCO, fases_button, border_radius=20)
    fases_text = fonte3.render('Selecionar fase', True, PRETO)

    tela.blit(fases_text,(fases_button.left + fases_button.width//2 - fases_text.get_width()//2,
    fases_button.top+fases_button.height//2 - fases_text.get_height()/2))

    #Botão "Como Jogar"
    htp_button = pygame.Rect(150, 550, 300, 50)
    pygame.draw.rect(tela, BRANCO, htp_button, border_radius=20)
    htp_text = fonte3.render('Como jogar', True, PRETO)

    tela.blit(htp_text,(htp_button.left + htp_button.width//2 - htp_text.get_width()//2,
    htp_button.top+htp_button.height//2 - htp_text.get_height()/2))

    # Botão "Sair"
    exit_button = pygame.Rect(150, 650, 300, 50)
    pygame.draw.rect(tela, BRANCO, exit_button, border_radius=20)
    exit_text = fonte3.render('Sair', True, PRETO)

    tela.blit(exit_text, (exit_button.left + exit_button.width//2 - exit_text.get_width()//2,
    exit_button.top+exit_button.height//2 - exit_text.get_height()//2))


    pygame.display.update()

def gerar_btn(texto):
    dificult_button = pygame.Rect(150, 350, 300, 50)
    pygame.draw.rect(tela, BRANCO, dificult_button, border_radius=20)
    dificult_text = fonte3.render('texto', True, PRETO)

    tela.blit(dificult_text,(dificult_button.left + dificult_button.width//2 - dificult_text.get_width()//2,
    dificult_button.top+dificult_button.height//2 - dificult_text.get_height()/2))

def mudar_parametro(parametro):
    nova_janela = pygame.display.set_mode((600, 800))

    if parametro == "dificuldade":
        pygame.display.set_caption("Selecione a dificuldade")
    else:
        pygame.display.set_caption("Selecione a fase")
    
    cadeado = True
    while cadeado:
        
        global fases, dificuldade
        clicado = False
        nova_janela.fill(AZUL_ESCURO)

        b1 = pygame.Rect(150, 200, 300, 100)
        pygame.draw.rect(nova_janela, BRANCO, b1, border_radius=20)
        b2 = pygame.Rect(150, 400, 300, 100)
        pygame.draw.rect(nova_janela, BRANCO, b2, border_radius=20)
        b3 = pygame.Rect(150, 600, 300, 100)
        pygame.draw.rect(nova_janela, BRANCO, b3, border_radius=20)
        if parametro == "dificuldade":
            b1_text = fonte3.render('Fácil', True, PRETO)
            b2_text = fonte3.render('Médio', True, PRETO)
            b3_text = fonte3.render('Difícil', True, PRETO)

        else:
            b1_text = fonte3.render('Terra', True, PRETO)
            b2_text = fonte3.render('Lua', True, PRETO)
            b3_text = fonte3.render('Vênus', True, PRETO)
        
        nova_janela.blit(b1_text, (b1.left + b1.width//2 - b1_text.get_width()//2, b1.top+b1.height//2 - b1_text.get_height()/2))
        nova_janela.blit(b2_text, (b2.left + b2.width//2 - b2_text.get_width()//2, b2.top+b2.height//2 - b2_text.get_height()/2))
        nova_janela.blit(b3_text, (b3.left + b3.width//2 - b3_text.get_width()//2, b3.top+b3.height//2 - b3_text.get_height()/2))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                cadeado = False
            elif event.type == pygame.MOUSEBUTTONDOWN and not clicado:
                if b1.collidepoint(event.pos):
                    clicado = True
                    if parametro == "dificuldade":
                        dificuldade = 1
                    else:
                        fases = 1
                    cadeado = False
                elif b2.collidepoint(event.pos) and not clicado:
                    clicado = True
                    if parametro == "dificuldade":
                        dificuldade = 2
                    else:
                        fases = 2
                    cadeado = False
                elif b3.collidepoint(event.pos) and not clicado:
                    clicado = True
                    if parametro == "dificuldade":
                        dificuldade = 3
                    else:
                        fases = 3
                    cadeado = False
            elif event.type == pygame.MOUSEBUTTONUP and clicado:
                clicado = False

        pygame.display.flip()

    # Retorna para a janela principal
    tela = pygame.display.set_mode((largura, altura))
    pygame.display.set_caption('Chairs!')
    draw_menu()

def abrir_pop_up():
    nova_janela = pygame.display.set_mode((600, 800))
    pygame.display.set_caption("Como jogar!")
    cadeado = True

    # Texto a ser exibido
    texto = ("Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
             "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, "
             "when an unknown printer took a galley of type and scrambled it to make a type specimen book. "
             "It has survived not only five centuries, but also the leap into electronic typesetting, "
             "remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets "
             "containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker "
             "including versions of Lorem Ipsum.")

    # Quebra o texto em várias linhas
    def quebra_texto(texto, fonte, largura_max):
        palavras = texto.split(" ")
        linhas = []
        linha_atual = ""
        for palavra in palavras:
            if fonte.size(linha_atual + palavra)[0] < largura_max:
                linha_atual += palavra + " "
            else:
                linhas.append(linha_atual)
                linha_atual = palavra + " "
        linhas.append(linha_atual)  # Adiciona a última linha
        return linhas

    # Quebrando o texto
    linhas = quebra_texto(texto, fonte5, 500)  # Limite de largura para o texto

    while cadeado:
        nova_janela.fill(AZUL_ESCURO)

        # Renderiza as linhas do texto
        y_offset = 50
        for linha in linhas:
            text_surface = fonte5.render(linha, True, BRANCO)
            nova_janela.blit(text_surface, (50, y_offset))
            y_offset += fonte5.get_height() + 5  # Ajusta a posição vertical para cada linha

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                cadeado = False

        pygame.display.flip()

    # Retorna para a janela principal
    tela = pygame.display.set_mode((largura, altura))
    pygame.display.set_caption('Chairs!')
    draw_menu()


# Função do jogo (apenas um exemplo simples de jogo)
def start_game(relogio):
    # Variáveis de Física
    g = 9.81  # Aceleração default
    air_rest = 0;
    angulo = 45  # Ângulo de lançamento em graus
    velocidade_inicial = 50  # Velocidade inicial
    t = 0  # Tempo

    #meta de pontuação default para a dificuldade
    meta_pontuacao = 15
    #tempo total default
    tempo_total = 60


    # Variáveis de controle de sensibilidade
    sens_ang = 0.5  # Velocidade de mudança do ângulo
    sens_vel = 0.5  # Velocidade de mudança da velocidade inicial

    # Posição inicial do projétil
    posicao_inicial_x, posicao_inicial_y = 100, altura - 400
    posicao_x, posicao_y = posicao_inicial_x, posicao_inicial_y



    lancado = False
    jogo_ativo = False
    pontuacao = 0
    tracado_pontos = []

    # Prepara a imagem da cadeira
    cadeira = pygame.image.load("images/cadeira.png")
    cadeira = pygame.transform.scale(cadeira, (200, 200))
    boneco_largura, boneco_altura = cadeira.get_size()

    # Prepara a imagem e caracteristicas do marcal
    marcal = pygame.image.load("images/marcal.png")

    tracado = pygame.image.load("images/quadrado.png")
    tracado = pygame.transform.scale(tracado, (7, 7))

    if dificuldade == 1:
        tempo_total = 60
        meta_pontuacao = 15
        marcal = pygame.transform.scale(marcal, (150, 150))
    elif dificuldade == 2:
        tempo_atual = 60
        meta_pontuacao = 20
        marcal = pygame.transform.scale(marcal, (125, 125))
    else:
        tempo_total = 30
        meta_pontuacao = 15
        marcal = pygame.transform.scale(marcal, (100, 100))

    marcal_largura, marcal_altura = marcal.get_size()
    marcal_x, marcal_y = 1290, 750

    # Sistema de tempo
    tempo_inicial = pygame.time.get_ticks()
    
    # Prepara o plano de fundo
    if fases == 1:
        g = 9.81
        fundo_img = pygame.image.load("images/debate.png").convert()
    elif fases == 2:
        g = 1.62
        fundo_img = pygame.image.load("images/lua2.png").convert()
    else:
        g = 8.87
        fundo_img = pygame.image.load("images/venus.jpeg").convert()
    
    fundo_img = pygame.transform.scale(fundo_img, (1600, 1200))

    #prepara o icone da resistencia do ar
    air_rest_icon = pygame.image.load("images/air_resistence.png")
    air_rest_icon = pygame.transform.scale(air_rest_icon, (100, 100))

    #prepara o icone da gravidade
    grav_icon = pygame.image.load("images/grav.png")
    grav_icon = pygame.transform.scale(grav_icon, (100, 100))

    jogo_ativo = True
    while jogo_ativo:
        
        tela.blit(fundo_img, (0, 0)) #desenha o fundo
        

        for evento in pygame.event.get(): #fechar jogo
            if evento.type == pygame.QUIT:
                jogo_ativo = False
   
        # Calcula o tempo restante
        tempo_atual = pygame.time.get_ticks()
        tempo_passado = (tempo_atual - tempo_inicial) // 1000  # Converte para segundos
        tempo_restante = tempo_total - tempo_passado
        if tempo_restante <= 0 and jogo_ativo:        # Verifica se o tempo acabou
            jogo_ativo = False

        if jogo_ativo:
            if not lancado:

                tracado_pontos.clear()

                # Processa entrada contínua das teclas
                angulo, velocidade_inicial, lancado, _ = processar_entrada_continua(sens_ang, sens_vel, lancado, angulo, velocidade_inicial)
                
                #cadeira = pygame.transform.rotate(boneco_aux, angulo);
                desenhar_vetor_direcao(posicao_x, posicao_y, angulo, velocidade_inicial)
                posicao_x, posicao_y = posicao_inicial_x, posicao_inicial_y

            # Atualiza a posição somente se foi lançado
            else:
                (posicao_x, posicao_y), _ = atualizar_posicao_e_velocidade(t, angulo, velocidade_inicial, posicao_inicial_x, posicao_inicial_y, g)
                t += 0.1

                # Verifica colisão com o marcal
                if verificar_colisao(
                    posicao_x + boneco_largura//2, posicao_y + boneco_altura // 2,
                    marcal_x + marcal_largura//2, marcal_y + marcal_altura//2,
                    0.6 * boneco_largura, 0.25 * marcal_largura
                ):
                    pontuacao += 1
                    lancado = False
                    # Reposiciona o marcal após acertar
                    marcal_x, marcal_y = reposicionar_marcal()
                    t = 0

            # Se o projétil sair da tela, reinicia
            if posicao_y > altura or posicao_x > largura:
                lancado = False
                posicao_x, posicao_y = posicao_inicial_x, posicao_inicial_y
                t = 0

            # Desenha o marcal
            tela.blit(marcal, (int(marcal_x), int(marcal_y)))

            # Desenha todos os pontos armazenados no traçado
            for i, ponto in enumerate(tracado_pontos):
                if i % 3 == 0:  # Se o índice for par, desenha o ponto
                    tela.blit(tracado, ponto)

            # Adiciona a posição atual ao traçado
            tracado_pontos.append((int(posicao_x + boneco_largura * 0.1), int(posicao_y + boneco_altura // 2)))

            # Desenha a imagem da cadeira
            tela.blit(cadeira, (int(posicao_x), int(posicao_y)))    

        # Interface do usuário
        fonte1 = pygame.font.Font(None, 36)
        
        # Mostra informações durante o jogo
        if jogo_ativo:
            texto_angulo = fonte1.render(f"Ângulo: {angulo:.1f}°", True, BRANCO)
            texto_velocidade = fonte1.render(f"Velocidade: {velocidade_inicial:.1f} m/s", True, BRANCO)
            texto_pontuacao = fonte1.render(f"Pontuação: {pontuacao}", True, VERDE)
            texto_tempo = fonte1.render(f"Tempo: {tempo_restante}s", True, VERMELHO)
            texto_meta = fonte1.render(f"Meta de pontos: {meta_pontuacao} pontos", True, AZUL) 
            texto_grav = fonte4.render(f"{g} m/s", True, BRANCO)
            texto_air_rest = fonte4.render(f"{air_rest} m/s", True, BRANCO)



            tela.blit(texto_angulo, (10, 10))
            tela.blit(texto_velocidade, (10, 50))
            tela.blit(texto_pontuacao, (10, 90))
            tela.blit(texto_tempo, (10, 130))
            tela.blit(texto_meta, (10, 170))
            tela.blit(air_rest_icon, (1000, 0)) #desenha o icone da gravidade
            tela.blit(grav_icon, (1300, 0))
            tela.blit(texto_air_rest, (1120 , air_rest_icon.get_height()/2 - texto_air_rest.get_height()/2) )
            tela.blit(texto_grav, (1420 , grav_icon.get_height()/2 - texto_grav.get_height()/2) )
        else:
            mostrar_resultados(pontuacao, meta_pontuacao)
            draw_menu()

        pygame.display.flip()
        relogio.tick(60)  # Aumentei para 60 FPS para movimento mais suave
#--------------------------------------------------------------------------------
# Função principal
def main():
    in_menu = True
    clicado = False
    draw_menu()

    start_button = pygame.Rect(150, 250, 300, 50)
    exit_button = pygame.Rect(150, 650, 300, 50)
    htp_button = pygame.Rect(150, 550, 300, 50)
    dificult_button = pygame.Rect(150, 350, 300, 50)
    fases_button = pygame.Rect(150, 450, 300, 50)

    while in_menu:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and not clicado:
                if start_button.collidepoint(event.pos):
                    jogo_ativo = True;
                    clicado = True;
                    relogio = pygame.time.Clock()
                    start_game(relogio)
                elif exit_button.collidepoint(event.pos):
                    clicado = True
                    pygame.quit()
                    sys.exit()
                elif htp_button.collidepoint(event.pos):
                    clicado = True
                    abrir_pop_up();
                elif dificult_button.collidepoint(event.pos):
                    clicado = True
                    mudar_parametro("dificuldade")
                elif fases_button.collidepoint(event.pos):
                    clicado = True
                    mudar_parametro("fases")
            elif event.type == pygame.MOUSEBUTTONUP and clicado:
                clicado = False

if __name__ == '__main__':
    main()
